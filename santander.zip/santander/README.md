# Fluxo de Negócios Kafka com Avro

## Visão Geral
Este projeto implementa um fluxo de mensagens Kafka usando o formato **Avro** para garantir uma comunicação estruturada e validada entre os tópicos. O sistema é dividido em componentes que representam **produtores** e **consumidores** para dois tópicos principais: `topic1` e `topic2`.

A estrutura reflete um fluxo empresarial onde mensagens JSON são convertidas, validadas e processadas com base em schemas definidos, antes de serem entregues ao próximo ponto do pipeline.

---

## Fluxo de Negócios

### 1. **Início do Processo com `SantanderStartEngine`**
- **Classe Responsável**: `SantanderStartEngine`
- **Descrição**:  
  Esta classe inicia o sistema enviando uma mensagem inicial no formato **JSON** para o `SantanderProducerTopic1`. Ela é usada para simular a entrada de dados no sistema de forma programática.
- **Papel no Fluxo**:  
  Dispara o processo, criando uma mensagem de exemplo e enviando-a para o tópico **`topic1`**.
- **Exemplo de Mensagem Criada**:
  ``` json
  {
    "id": "123",
    "value": "Hello Kafka from StartEngine!"
  }
  ```

---

### 2. **Produção de Mensagens no `topic1`**
- **Classe Responsável**: `SantanderProducerTopic1`
- **Descrição**:  
  Esta etapa recebe a mensagem criada pelo `SantanderStartEngine` e a envia ao **`topic1`**. O produtor simplesmente publica os dados no formato JSON no tópico.
- **Papel no Fluxo**:  
  Atua como ponto de entrada para as mensagens no pipeline Kafka, garantindo que elas sejam publicadas no primeiro tópico (`topic1`).

---

### 3. **Consumo de Mensagens do `topic1`**
- **Classe Responsável**: `SantanderConsumerTopic1`
- **Descrição**:  
  As mensagens enviadas para o `topic1` são consumidas nesta etapa. O consumidor lê cada mensagem JSON e passa o conteúdo para o **`SantanderStreamsProcessor`**, responsável pelo processamento e envio ao próximo tópico.

---

### 4. **Processamento de Mensagens**
- **Classe Responsável**: `SantanderStreamsProcessor`
- **Descrição**:  
  Esta etapa realiza o processamento da mensagem. As principais operações incluem:
  - **Leitura do Schema Avro**: O schema é carregado dinamicamente de um arquivo `.properties`.
  - **Validação e Serialização**: A mensagem JSON é convertida para um objeto Avro, validada contra o schema, e serializada para o formato binário Avro.
  - **Envio ao Próximo Tópico**: Após o processamento, a mensagem é enviada ao **`topic2`**.
- **Exemplo de Transformação**:
  - Mensagem Recebida no `topic1` (JSON):
    ``` json
    {
      "id": "123",
      "value": "Hello Kafka from StartEngine!"
    }
    ```
  - Mensagem Enviada para o `topic2` (binário Avro, mas logicamente):
    ``` json
    {
      "id": "123",
      "value": "HELLO KAFKA FROM STARTENGINE!"
    }
    ```

---

### 5. **Produção de Mensagens no `topic2`**
- **Classe Responsável**: `SantanderProducerTopic2`
- **Descrição**:  
  Este componente é opcional no fluxo, mas permite que mensagens sejam produzidas diretamente para o `topic2` caso necessário (como em cenários de teste ou fallback).

---

### 6. **Consumo de Mensagens do `topic2`**
- **Classe Responsável**: `SantanderConsumerTopic2`
- **Descrição**:  
  As mensagens processadas e serializadas no `topic2` são consumidas nesta etapa. O consumidor:
  - Desserializa a mensagem do formato binário Avro.
  - Exibe o conteúdo no console para análise e validação.

---

## Principais Regras de Negócio

1. **Validação do Schema Avro**:
   - Todas as mensagens processadas devem ser validadas contra o **schema Avro** definido no arquivo `message.avsc`.
   - Mensagens que não correspondem ao schema devem ser rejeitadas ou tratadas adequadamente.

2. **Conversão para Uppercase**:
   - Durante o processamento no `SantanderStreamsProcessor`, o campo `value` das mensagens é convertido para **uppercase** antes de ser enviado ao próximo tópico.

3. **Mensagens JSON como Entrada**:
   - O sistema aceita **JSON** como entrada inicial para os tópicos, mas utiliza **Avro (binário)** como formato de transporte entre os tópicos.

4. **Tópicos Independentes**:
   - Cada tópico (`topic1` e `topic2`) é tratado como uma entidade independente no sistema, garantindo flexibilidade para integrar novos processadores ou consumidores no futuro.

---

## Fluxo de Mensagens

1. **Envio de Mensagem Inicial**:
   - `SantanderStartEngine` cria uma mensagem JSON e envia para o `SantanderProducerTopic1`, que publica a mensagem no `topic1`.

2. **Consumo e Processamento**:
   - `SantanderConsumerTopic1` lê a mensagem do `topic1` e passa para o `SantanderStreamsProcessor`.
   - `SantanderStreamsProcessor` processa a mensagem, valida contra o schema Avro, e a envia para o `topic2`.

3. **Consumo Final**:
   - `SantanderConsumerTopic2` lê a mensagem processada do `topic2`, desserializa o conteúdo, e exibe o resultado no console.

---

## Apache Kafka - Structure

![Kafka Structure](doc/img/kafka-structure.jpg)

---

## Apache Kafka - Classes

![Classes Java](doc/img/kafka-java.jpg)
