package br.com.santander;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

public class SantanderProducerTopic1 {
    private final KafkaProducer<String, String> producer;

    public SantanderProducerTopic1() {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", StringSerializer.class.getName());
        props.put("value.serializer", StringSerializer.class.getName());
        this.producer = new KafkaProducer<>(props);
    }

    public void sendMessage(String key, String value) {
        ProducerRecord<String, String> record = new ProducerRecord<>("topic1", key, value);
        producer.send(record);
        System.out.println("Mensagem enviada para o topic1: " + value);
    }
}
