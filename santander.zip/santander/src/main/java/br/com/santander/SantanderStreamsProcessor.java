package br.com.santander;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.Encoder;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.specific.SpecificDatumWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class SantanderStreamsProcessor {
    private final Schema schema;

    public SantanderStreamsProcessor() throws Exception {
        // Lê o schema do arquivo de propriedades
        schema = loadSchema();
    }

    public static Schema loadSchema() throws Exception {
        Properties properties = new Properties();
        try (InputStream input = SantanderStreamsProcessor.class.getClassLoader().getResourceAsStream("schema.properties")) {
            if (input == null) {
                throw new Exception("Arquivo schema.properties não encontrado!");
            }
            properties.load(input);
        }
        String schemaPath = properties.getProperty("schema.path");
        return new Schema.Parser().parse(new File(schemaPath));
    }

    public void process(String jsonMessage, String targetTopic) throws Exception {
        // Converte o JSON em um registro Avro
        GenericRecord record = new GenericData.Record(schema);
        record.put("id", jsonMessage.split("\"id\": \"")[1].split("\"")[0]); // Extrai id
        record.put("value", jsonMessage.split("\"value\": \"")[1].split("\"")[0]); // Extrai value

        // Serializa o registro Avro
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        DatumWriter<GenericRecord> writer = new SpecificDatumWriter<>(schema);
        Encoder encoder = EncoderFactory.get().binaryEncoder(outputStream, null);
        writer.write(record, encoder);
        encoder.flush();
        byte[] serializedMessage = outputStream.toByteArray();

        // Envia a mensagem para o tópico destino
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");

        KafkaProducer<String, byte[]> producer = new KafkaProducer<>(props);
        producer.send(new ProducerRecord<>(targetTopic, serializedMessage));
        producer.close();
        System.out.println("Mensagem processada e enviada para o tópico: " + targetTopic);
    }
}
