package br.com.santander;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class SantanderConsumerTopic2 {
    public static void main(String[] args) throws Exception {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer");
        props.put("group.id", "topic2-consumer-group");

        KafkaConsumer<String, byte[]> consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Collections.singletonList("topic2"));

        // Load the schema once
        Schema schema = SantanderStreamsProcessor.loadSchema();

        while (true) {
            ConsumerRecords<String, byte[]> records = consumer.poll(Duration.ofMillis(100));
            for (ConsumerRecord<String, byte[]> record : records) {
                byte[] value = record.value();
                SpecificDatumReader<GenericRecord> reader = new SpecificDatumReader<>(schema);
                Decoder decoder = DecoderFactory.get().binaryDecoder(value, null);
                GenericRecord avroRecord = reader.read(null, decoder);

                System.out.println("Mensagem recebida no topic2: " + avroRecord);
            }
        }
    }
}
