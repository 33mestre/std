package br.com.santander;

import java.util.UUID;

public class SantanderStartEngine {
    public static void main(String[] args) throws Exception {
        System.out.println("Iniciando o sistema...");

        SantanderProducerTopic1 producer = new SantanderProducerTopic1();

        // Cria uma mensagem JSON
        String id = UUID.randomUUID().toString();
        String jsonMessage = String.format("{\"id\": \"%s\", \"value\": \"Hello Kafka from StartEngine!\"}", id);

        // Envia a mensagem para o topic1
        producer.sendMessage(id, jsonMessage);
    }
}
